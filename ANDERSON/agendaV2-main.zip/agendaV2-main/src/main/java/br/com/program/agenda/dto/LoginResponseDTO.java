package br.com.program.agenda.dto;

public record LoginResponseDTO(String token) {
}