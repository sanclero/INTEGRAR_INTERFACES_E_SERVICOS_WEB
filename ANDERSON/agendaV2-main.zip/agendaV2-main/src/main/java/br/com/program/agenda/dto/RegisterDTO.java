package br.com.program.agenda.dto;

import br.com.program.agenda.entities.UserRole;

public record RegisterDTO(String nome, String email, String login, String password, UserRole role) {
}