package br.com.program.agenda.dto;

public record AuthenticationDTO(String login, String password) {
}